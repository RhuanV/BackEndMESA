-- Demo município (synthetic MESA-A fixture; see PROVENANCE.md)

INSERT INTO mesa_a.vetor_limites_municipais (codigo_ibge, nome_municipio, sigla_estado, geom)
SELECT '9999999', 'Município Demonstração (MESA-A)', 'SP', ST_Multi(ST_SetSRID(ST_GeomFromText('POLYGON((-48.8 -22.5, -48.4 -22.5, -48.4 -22.1, -48.8 -22.1, -48.8 -22.5))'), 4674))
WHERE NOT EXISTS (SELECT 1 FROM mesa_a.vetor_limites_municipais WHERE codigo_ibge = '9999999');

INSERT INTO mesa_a.vetor_ibge_biomas (properties, geom)
SELECT '{"bioma": "Mata Atlântica", "seed": "demo"}'::jsonb, ST_SetSRID(ST_GeomFromText('POLYGON((-48.779999999999994 -22.48, -48.42 -22.48, -48.42 -22.12, -48.779999999999994 -22.12, -48.779999999999994 -22.48))'), 4674)
WHERE NOT EXISTS (SELECT 1 FROM mesa_a.vetor_ibge_biomas WHERE properties->>'seed' = 'demo');

INSERT INTO mesa_a.vetor_incra_quilombolas (properties, geom)
SELECT '{"nome": "Quilombo Demo", "seed": "demo"}'::jsonb, ST_SetSRID(ST_GeomFromText('POLYGON((-48.75 -22.45, -48.68 -22.45, -48.68 -22.38, -48.75 -22.38, -48.75 -22.45))'), 4674)
WHERE NOT EXISTS (SELECT 1 FROM mesa_a.vetor_incra_quilombolas WHERE properties->>'seed' = 'demo');

INSERT INTO mesa_a.vetor_incra_assentamentos (properties, geom)
SELECT '{"nome": "Assentamento Demo", "seed": "demo"}'::jsonb, ST_SetSRID(ST_GeomFromText('POLYGON((-48.54 -22.45, -48.449999999999996 -22.45, -48.449999999999996 -22.37, -48.54 -22.37, -48.54 -22.45))'), 4674)
WHERE NOT EXISTS (SELECT 1 FROM mesa_a.vetor_incra_assentamentos WHERE properties->>'seed' = 'demo');

INSERT INTO mesa_a.vetor_mma_florestas_publicas (properties, geom)
SELECT '{"nome": "Floresta Demo", "seed": "demo"}'::jsonb, ST_SetSRID(ST_GeomFromText('POLYGON((-48.75 -22.240000000000002, -48.65 -22.240000000000002, -48.65 -22.14, -48.75 -22.14, -48.75 -22.240000000000002))'), 4674)
WHERE NOT EXISTS (SELECT 1 FROM mesa_a.vetor_mma_florestas_publicas WHERE properties->>'seed' = 'demo');

INSERT INTO mesa_a.vetor_cprm_geodiversidade (properties, geom)
SELECT '{"classe": "Geo Demo", "seed": "demo"}'::jsonb, ST_SetSRID(ST_GeomFromText('POLYGON((-48.64 -22.34, -48.559999999999995 -22.34, -48.559999999999995 -22.26, -48.64 -22.26, -48.64 -22.34))'), 4674)
WHERE NOT EXISTS (SELECT 1 FROM mesa_a.vetor_cprm_geodiversidade WHERE properties->>'seed' = 'demo');
